from flask import Flask
from flask_cors import CORS
from models import banco
from controllers.controlador_grupo import controlador_grupo
from controllers.controlador_despesa import controlador_despesa
from controllers.auth import auth
import logging
import os

# 配置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, 
     resources={r"/api/*": {
         "origins": ["http://127.0.0.1:5500", "http://localhost:5500"],
         "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
         "allow_headers": ["Content-Type", "Authorization"],
         "supports_credentials": True
     }},
     supports_credentials=True
)

# 配置数据库
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 初始化数据库
banco.init_app(app)

# 注册蓝图
app.register_blueprint(controlador_grupo)
app.register_blueprint(controlador_despesa, url_prefix='/api')
app.register_blueprint(auth)

def init_db():
    try:
        with app.app_context():
            # 删除所有表
            banco.drop_all()
            # 创建所有表
            banco.create_all()
            logger.info("Database tables recreated successfully")
            
            # 验证数据库连接
            from models.usuario import Usuario
            user_count = Usuario.query.count()
            logger.info(f"Database connection verified. Current user count: {user_count}")
            
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        init_db()
        app.run(debug=True)
    except Exception as e:
        logger.error(f"Failed to start application: {str(e)}")
        raise