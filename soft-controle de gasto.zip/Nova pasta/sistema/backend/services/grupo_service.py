import random, string
from models import banco
from models.grupo import Grupo
from models.usuario import Usuario

class GrupoService:
    @staticmethod
    def gerar_codigo_convite():
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

    @staticmethod
    def criar_grupo(nome, descricao, regras, id_criador):
        usuario = Usuario.query.get(id_criador)
        if not usuario:
            return None, "Usuário não encontrado"

        grupo = Grupo(
            nome=nome,
            descricao=descricao,
            regras=regras,
            codigo_convite=GrupoService.gerar_codigo_convite()
        )
        grupo.membros.append(usuario)
        banco.session.add(grupo)
        banco.session.commit()
        return grupo, None

    @staticmethod
    def adicionar_membro_por_convite(codigo_convite, id_usuario):
        print(f"Searching for group with invite code: {codigo_convite}")
        
        # 先检查邀请码格式
        if not codigo_convite or len(codigo_convite) != 6:
            print(f"Invalid invite code format: {codigo_convite}")
            return None, "Código de convite inválido"
            
        # 转换为大写并查询
        codigo_convite = codigo_convite.upper()
        grupo = Grupo.query.filter_by(codigo_convite=codigo_convite).first()
        print(f"Found group: {grupo.nome if grupo else 'None'}")
        
        print(f"Searching for user with ID: {id_usuario}")
        usuario = Usuario.query.get(id_usuario)
        print(f"Found user: {usuario.email if usuario else 'None'}")
        
        if not grupo:
            print(f"No group found with invite code: {codigo_convite}")
            return None, "Código de convite inválido"
        if not usuario:
            print(f"No user found with ID: {id_usuario}")
            return None, "Usuário não encontrado"
        if usuario in grupo.membros:
            print(f"User {usuario.email} is already a member of group {grupo.nome}")
            return grupo, None
            
        try:
            grupo.membros.append(usuario)
            banco.session.commit()
            print(f"Added user {usuario.email} to group {grupo.nome}")
            
            # 验证用户是否成功添加
            grupo_atualizado = Grupo.query.get(grupo.id)
            if usuario not in grupo_atualizado.membros:
                raise Exception("Failed to add user to group")
            print(f"Verified user {usuario.email} is now a member of group {grupo.nome}")
            
            return grupo, None
        except Exception as e:
            banco.session.rollback()
            print(f"Error adding user to group: {str(e)}")
            return None, f"Erro ao adicionar usuário: {str(e)}"

    @staticmethod
    def listar_grupos_por_usuario(usuario_id):
        usuario = Usuario.query.get(usuario_id)
        if not usuario:
            return None
        return usuario.grupos_participante

    @staticmethod
    def remover_membro(grupo_id, id_usuario):
        grupo = Grupo.query.get(grupo_id)
        usuario = Usuario.query.get(id_usuario)
        if not grupo or not usuario:
            return False
        if usuario in grupo.membros:
            grupo.membros.remove(usuario)
            banco.session.commit()
            return True
        return False

    @staticmethod
    def verificar_membro(grupo_id, usuario_id):
        grupo = Grupo.query.get(grupo_id)
        usuario = Usuario.query.get(usuario_id)
        return grupo and usuario and usuario in grupo.membros
