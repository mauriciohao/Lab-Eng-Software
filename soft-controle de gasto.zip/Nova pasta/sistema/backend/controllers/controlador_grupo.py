from flask import Blueprint, request, jsonify
from services.grupo_service import GrupoService
from models import banco
from models.grupo import Grupo
from models.usuario import Usuario
import secrets
import string

controlador_grupo = Blueprint("controlador_grupo", __name__)

def gerar_codigo_convite():
    """Generate a random 6-character invitation code"""
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(6))

@controlador_grupo.route("/api/grupos", methods=["GET", "POST", "OPTIONS"])
def grupos():
    if request.method == "OPTIONS":
        return '', 200
    
    if request.method == "GET":
        usuario_id = request.args.get("usuario_id")
        grupos = GrupoService.listar_grupos_por_usuario(usuario_id)
        if grupos is None:
            return jsonify({"erro": "Usuário não encontrado"}), 404
        return jsonify([{
            "id": g.id,
            "nome": g.nome,
            "codigo_convite": g.codigo_convite,
            "membros": [{"id": m.id, "nome": m.nome, "email": m.email} for m in g.membros]
        } for g in grupos])
    
    if request.method == "POST":
        dados = request.json
        nome = dados.get("nome")
        descricao = dados.get("descricao")
        regras = dados.get("regras")
        membros_emails = dados.get("membros", [])

        if not nome or not regras:
            return jsonify({'success': False, 'message': 'Nome e regras são obrigatórios.'}), 400

        # Generate a unique invitation code
        codigo_convite = gerar_codigo_convite()
        print(f"Creating new group with invite code: {codigo_convite}")  # 添加日志
        
        # 检查邀请码是否已存在
        while Grupo.query.filter_by(codigo_convite=codigo_convite).first():
            codigo_convite = gerar_codigo_convite()
            print(f"Generated new invite code: {codigo_convite}")  # 添加日志
        
        try:
            grupo = Grupo(
                nome=nome, 
                descricao=descricao, 
                regras=regras,
                codigo_convite=codigo_convite
            )
            banco.session.add(grupo)
            banco.session.flush()
            print(f"Group created with ID: {grupo.id}")  # 添加日志

            # 添加创建者作为成员
            id_criador = dados.get("id_criador")
            if id_criador:
                criador = Usuario.query.get(id_criador)
                if criador:
                    grupo.membros.append(criador)
                    print(f"Added creator {criador.email} to group")  # 添加日志

            for email in membros_emails:
                usuario = Usuario.query.filter_by(email=email).first()
                if usuario and usuario not in grupo.membros:
                    grupo.membros.append(usuario)
                    print(f"Added member {email} to group")  # 添加日志

            banco.session.commit()
            print(f"Group saved to database with invite code: {grupo.codigo_convite}")  # 添加日志
            
            # 验证群组是否成功保存
            grupo_salvo = Grupo.query.get(grupo.id)
            if not grupo_salvo:
                raise Exception("Group was not saved to database")
            print(f"Verified group in database: {grupo_salvo.nome} with invite code: {grupo_salvo.codigo_convite}")  # 添加日志

        except Exception as e:
            banco.session.rollback()
            print(f"Error saving group: {str(e)}")  # 添加日志
            return jsonify({'success': False, 'message': f'Erro ao criar grupo: {str(e)}'}), 500

        return jsonify({
            'success': True,
            'grupo': {
                'id': grupo.id,
                'nome': grupo.nome,
                'descricao': grupo.descricao,
                'regras': grupo.regras,
                'codigo_convite': grupo.codigo_convite,
                'membros': [u.email for u in grupo.membros]
            }
        })

@controlador_grupo.route("/api/grupos/<int:grupo_id>", methods=["GET", "OPTIONS"])
def grupo_detalhes(grupo_id):
    if request.method == "OPTIONS":
        return '', 200
        
    grupo = Grupo.query.get(grupo_id)
    if not grupo:
        return jsonify({'erro': 'Grupo não encontrado'}), 404
    return jsonify({
        'id': grupo.id,
        'nome': grupo.nome,
        'descricao': grupo.descricao,
        'regras': grupo.regras,
        'codigo_convite': grupo.codigo_convite,
        'membros': [{'email': m.email} for m in grupo.membros]
    })

@controlador_grupo.route("/api/usuarios/<int:usuario_id>/grupos", methods=["GET", "OPTIONS"])
def usuario_grupos(usuario_id):
    if request.method == "OPTIONS":
        return '', 200
        
    grupos = GrupoService.listar_grupos_por_usuario(usuario_id)
    if grupos is None:
        return jsonify({"erro": "Usuário não encontrado"}), 404
    return jsonify([{
        "id": g.id,
        "nome": g.nome,
        "codigo_convite": g.codigo_convite,
        "membros": [{"id": m.id, "nome": m.nome, "email": m.email} for m in g.membros]
    } for g in grupos])

@controlador_grupo.route("/api/grupos/<int:grupo_id>/membros", methods=["POST", "OPTIONS"])
def adicionar_membro(grupo_id):
    if request.method == "OPTIONS":
        return '', 200
        
    dados = request.json
    grupo, erro = GrupoService.adicionar_membro_por_convite(
        codigo_convite=dados.get("codigo_convite"),
        id_usuario=dados.get("id_usuario")
    )
    if erro:
        return jsonify({"erro": erro}), 404
    return jsonify({"mensagem": "Usuário adicionado", "grupo_id": grupo.id})

@controlador_grupo.route("/api/grupos/<int:grupo_id>/membros/<int:usuario_id>", methods=["DELETE", "OPTIONS"])
def remover_membro(grupo_id, usuario_id):
    if request.method == "OPTIONS":
        return '', 200
        
    ok = GrupoService.remover_membro(grupo_id, usuario_id)
    if ok:
        return jsonify({"mensagem": "Removido com sucesso"})
    return jsonify({"erro": "Usuário ou grupo inválido"}), 404

@controlador_grupo.route("/api/grupos/<int:grupo_id>/membros/<int:usuario_id>/verificar", methods=["GET", "OPTIONS"])
def verificar_membro(grupo_id, usuario_id):
    if request.method == "OPTIONS":
        return '', 200
        
    membro = GrupoService.verificar_membro(grupo_id, usuario_id)
    return jsonify({"membro": membro})

@controlador_grupo.route("/api/grupos/entrar", methods=["POST", "OPTIONS"])
def entrar_grupo_por_convite():
    if request.method == "OPTIONS":
        return '', 200

    dados = request.json
    codigo_convite = dados.get("codigo_convite", "").upper()
    id_usuario = dados.get("id_usuario")
    
    print(f"Attempting to join group with code: {codigo_convite}")  # 添加日志
    
    if not codigo_convite or not id_usuario:
        return jsonify({"erro": "Código de convite e ID do usuário são obrigatórios"}), 400

    # 先检查数据库中是否存在这个邀请码
    grupo_existente = Grupo.query.filter_by(codigo_convite=codigo_convite).first()
    print(f"Found group in database: {grupo_existente.nome if grupo_existente else 'None'}")  # 添加日志

    grupo, erro = GrupoService.adicionar_membro_por_convite(
        codigo_convite=codigo_convite,
        id_usuario=id_usuario
    )
    
    if erro:
        print(f"Error joining group: {erro}")  # 添加日志
        return jsonify({"erro": erro}), 404
        
    print(f"Successfully joined group: {grupo.nome}")  # 添加日志
    return jsonify({
        "mensagem": "Usuário adicionado com sucesso",
        "grupo": {
            "id": grupo.id,
            "nome": grupo.nome,
            "codigo_convite": grupo.codigo_convite,
            "membros": [{"id": m.id, "nome": m.nome, "email": m.email} for m in grupo.membros]
        }
    })

@controlador_grupo.route("/api/debug/grupos", methods=["GET"])
def debug_grupos():
    grupos = Grupo.query.all()
    return jsonify([{
        "id": g.id,
        "nome": g.nome,
        "codigo_convite": g.codigo_convite,
        "membros": [{"id": m.id, "email": m.email} for m in g.membros]
    } for g in grupos])

@controlador_grupo.route("/api/debug/grupos/<codigo>", methods=["GET"])
def debug_grupo_por_codigo(codigo):
    grupo = Grupo.query.filter_by(codigo_convite=codigo).first()
    if not grupo:
        return jsonify({"erro": f"Nenhum grupo encontrado com o código: {codigo}"}), 404
    return jsonify({
        "id": grupo.id,
        "nome": grupo.nome,
        "codigo_convite": grupo.codigo_convite,
        "membros": [{"id": m.id, "email": m.email} for m in grupo.membros]
    })
