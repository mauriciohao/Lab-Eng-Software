from flask import Blueprint, request, jsonify
from models import banco
from models.despesa import Despesa
from models.divisao import Divisao
from models.usuario import Usuario
from models.grupo import Grupo
from datetime import datetime

controlador_despesa = Blueprint('controlador_despesa', __name__)

# Converter string de data para objeto datetime
def converter_data(data_str):
    if not data_str:
        return None
    try:
        return datetime.strptime(data_str, '%Y-%m-%d').date()
    except ValueError:
        return None

@controlador_despesa.route('/expenses', methods=['POST'])
def criar_despesa():
    dados = request.json
    
    # Validar dados obrigatórios
    if not all([dados.get('name'), dados.get('amount'), dados.get('payer_id'), dados.get('group_id')]):
        return jsonify({'erro': 'Dados incompletos'}), 400
    
    # Validar existência do grupo e pagador
    grupo = Grupo.query.get(dados.get('group_id'))
    pagador = Usuario.query.get(dados.get('payer_id'))
    
    if not grupo or not pagador:
        return jsonify({'erro': 'Grupo ou pagador não encontrado'}), 404
    
    # Criar despesa
    nova_despesa = Despesa(
        nome=dados.get('name'),
        descricao=dados.get('description'),
        estabelecimento=dados.get('establishment'),
        categoria=dados.get('category'),
        valor=float(dados.get('amount')),
        data=converter_data(dados.get('date')) or datetime.today().date(),
        data_limite=converter_data(dados.get('due_date')),
        grupo_id=dados.get('group_id'),
        pagador_id=dados.get('payer_id'),
        metodo_divisao='manual' if dados.get('settlement_type') == 'manual' else 'igual',
        status='pendente'
    )
    
    banco.session.add(nova_despesa)
    banco.session.flush()  # Para obter o ID da nova despesa
    
    # Processar divisão da despesa
    if nova_despesa.metodo_divisao == 'igual':
        # Divisão igual entre todos os membros
        membros = list(grupo.membros)
        valor_por_membro = nova_despesa.valor / len(membros)
        
        for membro in membros:
            # O pagador não deve a si mesmo
            if membro.id != pagador.id:
                divisao = Divisao(
                    despesa_id=nova_despesa.id,
                    usuario_id=membro.id,
                    valor=valor_por_membro
                )
                banco.session.add(divisao)
    else:
        # Divisão manual conforme informado
        manual_debts = dados.get('manual_debts', {})
        for usuario_id, valor in manual_debts.items():
            # Converter para int se for string
            usuario_id = int(usuario_id)
            if usuario_id != pagador.id and valor > 0:
                divisao = Divisao(
                    despesa_id=nova_despesa.id,
                    usuario_id=usuario_id,
                    valor=float(valor)
                )
                banco.session.add(divisao)
    
    banco.session.commit()
    
    return jsonify({
        'id': nova_despesa.id,
        'nome': nova_despesa.nome,
        'valor': nova_despesa.valor
    }), 201

@controlador_despesa.route('/groups/<int:grupo_id>/expenses', methods=['GET'])
def listar_despesas_grupo(grupo_id):
    grupo = Grupo.query.get(grupo_id)
    if not grupo:
        return jsonify({'erro': 'Grupo não encontrado'}), 404
    
    despesas = Despesa.query.filter_by(grupo_id=grupo_id).all()
    
    return jsonify([{
        'id': d.id,
        'name': d.nome,
        'description': d.descricao,
        'category': d.categoria,
        'amount': d.valor,
        'date': d.data.strftime('%Y-%m-%d'),
        'due_date': d.data_limite.strftime('%Y-%m-%d') if d.data_limite else None,
        'status': d.status,
        'payer_id': d.pagador_id
    } for d in despesas])

@controlador_despesa.route('/expenses/<int:despesa_id>', methods=['GET'])
def obter_despesa(despesa_id):
    despesa = Despesa.query.get(despesa_id)
    if not despesa:
        return jsonify({'erro': 'Despesa não encontrada'}), 404
    
    return jsonify({
        'id': despesa.id,
        'name': despesa.nome,
        'description': despesa.descricao,
        'category': despesa.categoria,
        'amount': despesa.valor,
        'date': despesa.data.strftime('%Y-%m-%d'),
        'due_date': despesa.data_limite.strftime('%Y-%m-%d') if despesa.data_limite else None,
        'status': despesa.status,
        'payer_id': despesa.pagador_id,
        'group_id': despesa.grupo_id
    })

@controlador_despesa.route('/expenses/<int:despesa_id>/settlement', methods=['GET'])
def obter_liquidacao(despesa_id):
    despesa = Despesa.query.get(despesa_id)
    if not despesa:
        return jsonify({'erro': 'Despesa não encontrada'}), 404
    
    divisoes = Divisao.query.filter_by(despesa_id=despesa_id).all()
    
    debitos = {}
    for divisao in divisoes:
        usuario = Usuario.query.get(divisao.usuario_id)
        debitos[usuario.nome] = divisao.valor
    
    return jsonify({
        'despesa_id': despesa_id,
        'debts': debitos
    })

@controlador_despesa.route('/expenses/<int:despesa_id>/status', methods=['PUT'])
def atualizar_status(despesa_id):
    dados = request.json
    status = dados.get('status')
    
    if not status:
        return jsonify({'erro': 'Status não informado'}), 400
    
    despesa = Despesa.query.get(despesa_id)
    if not despesa:
        return jsonify({'erro': 'Despesa não encontrada'}), 404
    
    despesa.status = status
    banco.session.commit()
    
    return jsonify({'mensagem': 'Status atualizado com sucesso'})