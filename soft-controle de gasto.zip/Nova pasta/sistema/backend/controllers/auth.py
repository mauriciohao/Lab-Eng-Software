from flask import Blueprint, request, jsonify
from models.usuario import Usuario
from models import banco
import logging
import traceback

# 配置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

auth = Blueprint('auth', __name__)

@auth.route('/api/register', methods=['POST', 'OPTIONS'])
def register():
    if request.method == 'OPTIONS':
        return '', 200
    data = request.json
    nome = data.get('nome')
    email = data.get('email')
    username = data.get('username')
    senha = data.get('senha')
    
    # 验证必填字段
    if not all([nome, email, username, senha]):
        return jsonify({
            'success': False,
            'message': 'Por favor, preencha todos os campos obrigatórios.'
        }), 400
    
    # 验证用户名长度
    if len(username) < 3:
        return jsonify({
            'success': False,
            'message': 'O nome de usuário deve ter pelo menos 3 caracteres.'
        }), 400
    
    # 验证密码长度
    if len(senha) < 6:
        return jsonify({
            'success': False,
            'message': 'A senha deve ter pelo menos 6 caracteres.'
        }), 400
    
    # 检查邮箱是否已存在
    if Usuario.query.filter_by(email=email).first():
        return jsonify({
            'success': False,
            'message': 'Este email já está cadastrado.'
        }), 400
    
    # 检查用户名是否已存在
    if Usuario.query.filter_by(username=username).first():
        return jsonify({
            'success': False,
            'message': 'Este nome de usuário já está em uso.'
        }), 400
    
    try:
        # 创建新用户
        novo_usuario = Usuario(
            nome=nome,
            email=email,
            username=username,
            senha=senha
        )
        
        # 保存到数据库
        banco.session.add(novo_usuario)
        banco.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Cadastro realizado com sucesso!'
        })
        
    except Exception as e:
        logger.error(f"Erro ao registrar usuário: {str(e)}")
        logger.error(traceback.format_exc())
        banco.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Erro ao realizar cadastro. Tente novamente.'
        }), 500

@auth.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 200
        
    try:
        logger.debug("Iniciando processo de login")
        
        if not request.is_json:
            logger.warning("Content-Type não é application/json")
            return jsonify({
                'success': False,
                'message': 'Content-Type must be application/json'
            }), 415
            
        data = request.get_json()
        logger.debug(f"Dados recebidos: {data}")
        
        login_id = data.get('loginId')
        senha = data.get('password')
        
        if not login_id or not senha:
            logger.warning("Dados incompletos")
            return jsonify({'success': False, 'message': 'Dados incompletos'}), 400
        
        logger.debug(f"Tentando login com: {login_id}")
        
        try:
            # 尝试通过邮箱查找用户
            user = Usuario.query.filter_by(email=login_id, senha=senha).first()
            logger.debug(f"Busca por email: {login_id}")
            
            # 如果没找到，尝试通过用户名查找
            if not user:
                logger.debug(f"Busca por username: {login_id}")
                user = Usuario.query.filter_by(username=login_id, senha=senha).first()
            
            if not user:
                logger.warning(f"Usuário não encontrado: {login_id}")
                return jsonify({'success': False, 'message': 'Email/usuário ou senha inválidos!'}), 401
            
            logger.info(f"Login bem-sucedido para: {login_id}")
            return jsonify({
                'success': True,
                'user': {
                    'id': user.id,
                    'nome': user.nome,
                    'email': user.email,
                    'username': user.username
                }
            })
            
        except Exception as e:
            logger.error(f"Erro ao consultar banco de dados: {str(e)}")
            logger.error(traceback.format_exc())
            return jsonify({
                'success': False,
                'message': 'Erro ao consultar banco de dados'
            }), 500
        
    except Exception as e:
        logger.error(f"Erro durante login: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'message': 'Erro interno do servidor'
        }), 500 