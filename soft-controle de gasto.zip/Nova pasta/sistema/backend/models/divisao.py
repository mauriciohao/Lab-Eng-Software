from models import banco

class Divisao(banco.Model):
    __tablename__ = 'divisoes'
    despesa_id = banco.Column(banco.Integer, banco.ForeignKey('despesas.id'), primary_key=True)
    usuario_id = banco.Column(banco.Integer, banco.ForeignKey('usuarios.id'), primary_key=True)
    valor = banco.Column(banco.Float, nullable=False)
    status = banco.Column(banco.String(20), default='pendente')  # pendente, pago