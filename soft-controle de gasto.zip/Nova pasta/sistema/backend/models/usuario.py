from models import banco
from sqlalchemy.orm import relationship

class Usuario(banco.Model):
    __tablename__ = 'usuarios'
    id = banco.Column(banco.Integer, primary_key=True)
    nome = banco.Column(banco.String(100), nullable=False)
    email = banco.Column(banco.String(120), unique=True, nullable=False)
    username = banco.Column(banco.String(50), unique=True, nullable=False)
    senha = banco.Column(banco.String(100), nullable=False)
    telefone = banco.Column(banco.String(20))
    nascimento = banco.Column(banco.String(10))
    cpf = banco.Column(banco.String(14))

    # 用户作为成员加入的群组
    grupos_participante = relationship('Grupo', 
        secondary='grupo_usuario',
        back_populates='membros',
        lazy='dynamic'
    )

    def __init__(self, nome, email, username, senha):
        self.nome = nome
        self.email = email
        self.username = username
        self.senha = senha