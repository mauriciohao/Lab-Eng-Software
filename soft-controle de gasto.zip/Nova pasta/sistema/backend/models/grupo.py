from models import banco
from sqlalchemy.orm import relationship

# 定义关联表
grupo_usuario = banco.Table('grupo_usuario',
    banco.Column('grupo_id', banco.Integer, banco.ForeignKey('grupos.id'), primary_key=True),
    banco.Column('usuario_id', banco.Integer, banco.ForeignKey('usuarios.id'), primary_key=True)
)

class Grupo(banco.Model):
    __tablename__ = 'grupos'
    id = banco.Column(banco.Integer, primary_key=True)
    nome = banco.Column(banco.String(100), nullable=False)
    descricao = banco.Column(banco.Text)
    regras = banco.Column(banco.Text, nullable=False)
    codigo_convite = banco.Column(banco.String(6), unique=True, nullable=False)

    # 群组的成员
    membros = relationship('Usuario', 
        secondary=grupo_usuario,
        back_populates='grupos_participante',
        lazy='dynamic'
    )

    def __init__(self, nome, descricao, regras, codigo_convite):
        self.nome = nome
        self.descricao = descricao
        self.regras = regras
        self.codigo_convite = codigo_convite.upper()
