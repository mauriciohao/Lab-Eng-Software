from models import banco
from datetime import datetime
from sqlalchemy.orm import relationship

class Despesa(banco.Model):
    __tablename__ = 'despesas'
    id = banco.Column(banco.Integer, primary_key=True)
    nome = banco.Column(banco.String(100), nullable=False)
    descricao = banco.Column(banco.Text)
    estabelecimento = banco.Column(banco.String(100))
    categoria = banco.Column(banco.String(50))
    valor = banco.Column(banco.Float, nullable=False)
    data = banco.Column(banco.Date, nullable=False, default=datetime.today)
    data_limite = banco.Column(banco.Date)
    status = banco.Column(banco.String(20), default='pendente')  # pendente, pago, cancelado
    
    # Relacionamentos
    grupo_id = banco.Column(banco.Integer, banco.ForeignKey('grupos.id'), nullable=False)
    grupo = relationship('Grupo', backref='despesas')
    
    pagador_id = banco.Column(banco.Integer, banco.ForeignKey('usuarios.id'), nullable=False)
    pagador = relationship('Usuario', foreign_keys=[pagador_id], backref='despesas_pagas')
    
    metodo_divisao = banco.Column(banco.String(10), default='igual')  # igual, manual, percentual