from models import banco

membros = banco.Table('membros',
    banco.Column('usuario_id', banco.Integer, banco.ForeignKey('usuarios.id'), primary_key=True),
    banco.Column('grupo_id', banco.Integer, banco.ForeignKey('grupos.id'), primary_key=True)
)
