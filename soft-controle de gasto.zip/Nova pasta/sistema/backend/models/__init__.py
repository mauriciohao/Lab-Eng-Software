from flask_sqlalchemy import SQLAlchemy
banco = SQLAlchemy()

def inicializar_banco(app):
    with app.app_context():
        from .usuario import Usuario
        from .grupo import Grupo
        from .membros import membros
        from .despesa import Despesa
        from .divisao import Divisao
        
        banco.create_all()
        print("✅ Banco de dados inicializado com sucesso.")