import { API_BASE_URL, fetchWithErrorHandling, showError, showSuccess } from './config.js';

// Funções de autenticação
export async function handleLogin(event) {
    event.preventDefault();
    const loginId = document.getElementById('email').value || document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch(`${API_BASE_URL}/api/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ loginId, password })
        });
        
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message || 'Erro ao fazer login.');
        }
        
        // Ensure the user object has all required fields
        if (!data.user || !data.user.id) {
            throw new Error('Dados do usuário incompletos. Por favor, tente novamente.');
        }
        
        // Store the complete user object
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        window.location.href = 'home.html';
    } catch (error) {
        showError(error.message || 'Erro ao fazer login.');
    }
}

export async function handleRegister(event) {
    if (event) event.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;
    
    // Validações básicas
    if (!nome || !email || !username || !senha) {
        showError('Por favor, preencha todos os campos obrigatórios!');
        return;
    }
    
    if (senha !== confirmarSenha) {
        showError('As senhas não coincidem!');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome,
                email,
                username,
                senha
            })
        });
        
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.message || 'Erro ao registrar usuário.');
        }
        
        showSuccess('Cadastro realizado com sucesso!');
        window.location.href = 'index.html';
    } catch (error) {
        showError(error.message || 'Erro ao registrar usuário. Por favor, tente novamente.');
    }
}

export function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

// Inicializar componentes de autenticação
export function initAuthComponents() {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }
}