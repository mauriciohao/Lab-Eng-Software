// Criar novo grupo
async function criarGrupo() {
    const nomeGrupo = document.getElementById('nomeGrupo').value.trim();
    const descricao = document.getElementById('descricao').value.trim();
    const regras = document.getElementById('regras').value.trim();
    const currentUser = window.checkUserSession();
    // 获取成员email列表（如果有）
    const membros = Array.from(document.querySelectorAll('#listaMembros .email-item')).map(e => e.textContent.trim());

    if (!nomeGrupo || !regras) {
        window.showError('Por favor, preencha todos os campos obrigatórios.');
        return;
    }
    try {
        const response = await window.fetchWithErrorHandling(`${window.API_BASE_URL}/grupos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                nome: nomeGrupo,
                descricao,
                regras,
                membros,
                id_criador: currentUser.id
            })
        });
        console.log('创建群组返回：', response);
        // 创建后立即刷新群组列表到 localStorage
        const userId = currentUser.id;
        const gruposResp = await window.fetchWithErrorHandling(`${window.API_BASE_URL}/usuarios/${userId}/grupos`);
        if (gruposResp.ok) {
            const gruposData = await gruposResp.json();
            localStorage.setItem('groups', JSON.stringify(gruposData));
        }
        const groupId = response.grupo ? response.grupo.id : response.id;
        window.location.href = `grupo-detalhes.html?id=${groupId}`;
    } catch (error) {
        window.showError(error.message || 'Erro ao criar grupo.');
    }
}

function copyInviteCode() {
    const inviteCodeInput = document.getElementById('inviteCode');
    inviteCodeInput.select();
    document.execCommand('copy');
    window.showSuccess('Código de convite copiado para a área de transferência!');
}

window.criarGrupo = criarGrupo;
window.copyInviteCode = copyInviteCode;

// Entrar em um grupo com código de convite
async function entrarGrupo(event) {
    if (event) event.preventDefault();
    
    const codigo = document.getElementById('codigoConvite').value.trim();
    
    if (!codigo) {
        window.showError('Por favor, insira um código de convite.');
        return;
    }

    const currentUser = window.checkUserSession();
    if (!currentUser) {
        window.showError('Por favor, faça login para entrar em um grupo.');
        window.location.href = 'index.html';
        return;
    }

    try {
        const respostaAdicao = await window.fetchWithErrorHandling(`${window.API_BASE_URL}/grupos/entrar`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${currentUser.token}`
            },
            body: JSON.stringify({
                codigo_convite: codigo,
                id_usuario: currentUser.id
            })
        });

        window.showSuccess('Você foi adicionado ao grupo com sucesso!');
        // 更新本地存储的组列表
        const gruposAtuais = JSON.parse(localStorage.getItem('groups') || '[]');
        gruposAtuais.push(respostaAdicao.grupo);
        localStorage.setItem('groups', JSON.stringify(gruposAtuais));
        // 重定向到组详情页面
        window.location.href = `grupo-detalhes.html?id=${respostaAdicao.grupo.id}`;
    } catch (error) {
        window.showError(error.message || 'Erro ao entrar no grupo. Por favor, tente novamente.');
    }
}

// Carregar grupos do usuário
async function carregarGruposUsuario() {
    const currentUser = window.checkUserSession();
    if (!currentUser) {
        window.showError('Por favor, faça login novamente.');
        window.location.href = 'index.html';
        return;
    }

    if (!currentUser.id) {
        window.showError('Erro na sessão do usuário. Por favor, faça login novamente.');
        window.location.href = 'index.html';
        return;
    }

    try {
        const resposta = await window.fetchWithErrorHandling(`${window.API_BASE_URL}/usuarios/${currentUser.id}/grupos`);
        if (!resposta.ok) {
            throw new Error('Erro ao carregar grupos');
        }

        const gruposData = await resposta.json();
        console.log('Grupos carregados:', gruposData);

        // Salva para outras páginas
        localStorage.setItem("groups", JSON.stringify(gruposData));

        const groupsList = document.getElementById('groupsList');
        const noGroups = document.getElementById('noGroups');

        if (!groupsList || !noGroups) return;

        if (gruposData.length === 0) {
            groupsList.style.display = 'none';
            noGroups.style.display = 'block';
        } else {
            groupsList.style.display = 'block';
            noGroups.style.display = 'none';
            groupsList.innerHTML = gruposData.map(grupo => `
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="card-title">${grupo.nome}</h5>
                                <p class="card-text text-muted">
                                    ${grupo.membros ? grupo.membros.length : 0} membro${grupo.membros && grupo.membros.length > 1 ? 's' : ''}
                                </p>
                            </div>
                            <a href="grupo-detalhes.html?id=${grupo.id}" class="btn btn-primary">
                                Ver Detalhes
                            </a>
                        </div>
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        window.showError(error.message || 'Erro ao carregar grupos.');
    }
}

// Carregar detalhes de um grupo específico
async function carregarDetalhesGrupo(grupoId) {
    try {
        const currentUser = window.checkUserSession();
        if (!currentUser) return;
        
        // Verificar se o usuário é membro do grupo
        const ehMembro = await window.fetchWithErrorHandling(
            `${window.API_BASE_URL}/grupos/${grupoId}/verificar/${currentUser.id}`
        );
        
        if (!ehMembro.membro) {
            window.showError('Você não tem acesso a este grupo.');
            window.location.href = 'home.html';
            return;
        }
        
        // Buscar dados do grupo no cache
        const gruposCache = JSON.parse(localStorage.getItem('groups') || '[]');
        const grupo = gruposCache.find(g => g.id == grupoId);
        
        if (grupo) {
            // Preencher informações do grupo
            document.getElementById('groupName').textContent = grupo.nome;
            document.getElementById('groupInviteCode').textContent = grupo.codigo_convite;
        }
    } catch (error) {
        window.showError(error.message || 'Erro ao carregar detalhes do grupo. Por favor, tente novamente mais tarde.');
    }
}

function goToDetails() {
    window.location.href = 'grupo-detalhes.html';
}

window.goToDetails = goToDetails;

// 导出函数到全局作用域
window.entrarGrupo = entrarGrupo;

function handleGroupDisplay(grupos) {
    const groupListElement = document.getElementById('groupList');

    if (!groupListElement) {
        console.error("无法找到 groupList 元素");
        return;
    }

    if (grupos.length === 0) {
        groupListElement.innerHTML = '<p>Você ainda não está em nenhum grupo.</p>';
    } else {
        // 正常展示群组
        groupListElement.innerHTML = grupos.map(grupo => `<p>${grupo.nome}</p>`).join('');
    }
}