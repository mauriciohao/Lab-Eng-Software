// Configuração da API
const API_BASE_URL = 'http://localhost:5000/api';

// Função utilitária para fazer requisições com tratamento de erro
async function fetchWithErrorHandling(url, options = {}) {
    try {
        const response = await fetch(url, options);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ erro: 'Erro desconhecido' }));
            throw new Error(errorData.erro || `Erro HTTP: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error("Erro na requisição:", error);
        throw error;
    }
}

// Função para verificar se o usuário está logado
function checkUserSession() {
    const currentUser = localStorage.getItem('currentUser');
    if (!currentUser) {
        window.location.href = 'index.html';
        return null;
    }
    
    try {
        const user = JSON.parse(currentUser);
        if (!user || !user.id) {
            // Invalid user data, clear it and redirect
            localStorage.removeItem('currentUser');
            window.location.href = 'index.html';
            return null;
        }
        return user;
    } catch (error) {
        // Invalid JSON, clear it and redirect
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
        return null;
    }
}

// Função para exibir mensagens de erro
function showError(message) {
    const errorElement = document.getElementById('error-message');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        
        // Esconder a mensagem após 5 segundos
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    } else {
        alert(message);
    }
}

// Função para exibir mensagens de sucesso
function showSuccess(message) {
    const successElement = document.getElementById('success-message');
    if (successElement) {
        successElement.textContent = message;
        successElement.style.display = 'block';
        
        // Esconder a mensagem após 5 segundos
        setTimeout(() => {
            successElement.style.display = 'none';
        }, 5000);
    } else {
        alert(message);
    }
}

// 挂载到全局
window.API_BASE_URL = API_BASE_URL;
window.fetchWithErrorHandling = fetchWithErrorHandling;
window.checkUserSession = checkUserSession;
window.showError = showError;
window.showSuccess = showSuccess;